import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';

class RedButton extends Component{
  render(){
    return(
      <Button color= "#008080" title="dame click"/>
    );
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{marginTop:100}}>
      <RedButton/>
        <Text style={{marginTop:50}}>Mi Primer componente React</Text>
        </View>
    );
  }
}